<?php
    use Illuminate\Support\Str;
?>



<?php $__env->startSection('content'); ?>

      <div class="card shadow">
        <div class="card-header border-0">
          <div class="row align-items-center">
            <div class="col">
              <h3 class="mb-0">Editar Paciente</h3>
            </div>
            <div class="col text-right">
              <a href="<?php echo e(url('/pacientes')); ?>" class="btn btn-sm btn-primary">regresar</a>
            </div>
          </div>
        </div>
        <div class="card-body">

            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger" role="alert">
                        <strong>Por favor</strong> <?php echo e($error); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>
            <form method="POST" action="<?php echo e(url('/pacientes/'.$patient->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="name">nombre del medico</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $patient->name)); ?>" >
                </div>
                <div class="form-group">
                    <label for="email">correo electronico</label>
                    <input type="text" name="email" class="form-control" value="<?php echo e(old('email', $patient->email)); ?>">

                </div>
                <div class="form-group">
                    <label for="cedula">cedula</label>
                    <input type="text" name="cedula" class="form-control" value="<?php echo e(old('cedula', $patient->cedula)); ?>">
                </div>
                <div class="form-group">
                    <label for="address">direccion</label>
                    <input type="text" name="address" class="form-control" value="<?php echo e(old('address', $patient->address)); ?>">

                </div>
                <div class="form-group">
                    <label for="phone">Telefono</label>
                    <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone', $patient->phone)); ?>">
                </div>
                <div class="form-group">
                    <label for="password">Contraseña</label>
                    <input type="text" name="password" class="form-control">
                    <small class="text-warning">Solo llena el campo si deseas cambia la contraseña</small>
                </div>
                <button type="submit" class="btn btn-sm btn-primary">crear</button>
            </form>
        </div>
      </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/citas-medicas/resources/views/patients/edit.blade.php ENDPATH**/ ?>