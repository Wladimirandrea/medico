<?php
    use Illuminate\Support\Str;
?>


<?php $__env->startSection('content'); ?>

      <div class="card shadow">
        <div class="card-header border-0">
          <div class="row align-items-center">
            <div class="col">
              <h3 class="mb-0">Registrar cita</h3>
            </div>
            <div class="col text-right">
              <a href="<?php echo e(url('/')); ?>" class="btn btn-sm btn-primary">regresar</a>
            </div>
          </div>
        </div>
        <div class="card-body">

            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger" role="alert">
                        <strong>Por favor</strong> <?php echo e($error); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>
            <form method="POST" action="<?php echo e(url('/reservarcitas')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="specialty">Especialidad</label>
                    <select name="specialty_id" id="specialty" class="form-control">
                        <option value="">Seleccionar especialidad</option>
                        <?php $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($especialidad->id); ?>"><?php echo e($especialidad->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="doctor">Medico</label>
                    <select name="doctor_id" id="doctor" class="form-control"></select>

                </div>
                <div class="form-group">
                    <label for="fecha">Fecha</label>
                    <div class="form-group">
                        <div class="input-group">
                            <div class="input-group-prepend">
                               <span class="input-group-text">
                                    <i class="ni ni-calendar-grid-58"></i>
                                </span>
                            </div>
                            <input class="form-control datepicker"
                            id="date"
                            placeholder="Seleccionar Fecha"
                            type="text" value="<?php echo e(date('Y-m-d')); ?>"
                            data-date-format="yyyy-mm-dd"
                            data-date-start-date="<?php echo e(date('Y-m-d')); ?>"
                            data-date-end-date="+30d">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="address">Hora de Atencion</label>
                    <div class="container">
                        <div class="row">
                            <div class="col">
                                <h4 class="m-3" id="titleMorning"></h4>
                                <div id="hoursMorning"></div>
                            </div>
                            <div class="col">
                                <h4 class="m-3" id="titleAfternoon"></h4>
                                <div id="hoursAfternoon"></div>
                            </div>

                        </div>
                    </div>

                </div>
                <div class="form-group">
                    <label for="phone">Tipo de consulta</label>
                    <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone')); ?>" required>

                </div>

                <button type="submit" class="btn btn-sm btn-primary">crear cita</button>
            </form>
        </div>
      </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('/js/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/appointments/create.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/citas-medicas/resources/views/appointments/create.blade.php ENDPATH**/ ?>