<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Specialty;

class SpecialtiesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $specialties = [
            'Neurologia',
            'Quirurgica',
            'Pediatria',
            'Cardiologia',
            'Urologia',
            'medicina Forense',
            'dermatologia',
        ];
        foreach ($specialties as $specialty){
            Specialty::create([
                'name' => $specialty
            ]);
        }
    }
}
